﻿using Xunit;

namespace UniqueWordCounter.Test
{
    public class TextFileValidatorTests
    {
        [Fact]
        public void Validate_Returns_False_When_File_Does_Not_Exist()
        {
            //Arrange
            var sut=new TextFileValidator();
            //Act
            var validationResult= sut.Validate("NonExistingFile.txt");
            //Assert
            Assert.False(validationResult.IsValid);
            Assert.NotEmpty(validationResult.Messages);
        }
        [Fact]
        public void Validate_Returns_False_And_Error_Message_When_File_Type_Is_Not_txt()
        {
            //Arrange
            var sut = new TextFileValidator();
            //Act
            var validationResult = sut.Validate(@"..\..\TestFiles\flower.jpg");
            //Assert
            Assert.False(validationResult.IsValid);
            Assert.NotEmpty(validationResult.Messages);
        }

        [Fact]
        public void Validate_Returns_True_When_File_Exist_And_It_Is_A_txt_File()
        {
            //Arrange
            var sut = new TextFileValidator();
            //Act
            var validationResult = sut.Validate(@"..\..\TestFiles\Example.txt");
            //Assert
            Assert.True(validationResult.IsValid);
            Assert.Empty(validationResult.Messages);
        }
    }
}
