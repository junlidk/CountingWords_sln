﻿using System;
using System.Collections.Generic;
using Xunit;

namespace UniqueWordCounter.Test
{
    public class ExtentionsTests
    {
        [Fact]
        public void GetDisplay_Throws_ArgumentNullException_When_Dictionary_Is_Null()
        {
            //Arrange
            IDictionary<string, int> wordCounts = null;
            //Assert
            Assert.Throws<ArgumentNullException>(() => wordCounts.GetDisplay());

        }

        [Fact]
        public void GetDisplay_Returns_Expected_Result_When_Dictionary_Is_Not_Empty()
        {
            //Arrange
            var wordCounts = new Dictionary<string, int> { { "hello", 1 }, { "world", 2 } };
            string expected = $"1 : hello{Environment.NewLine}2 : world{Environment.NewLine}";
            //Act
            string actual = wordCounts.GetDisplay();
            //Assert
            Assert.Equal(expected, actual);
        }


        [Fact]
        public void GetDisplay_Returns_Empty_String_When_Dictionary_Is_Empty()
        {
            //Arrange
            var wordCounts = new Dictionary<string, int>();
            //Act
            string actual = wordCounts.GetDisplay();
            //Assert
            Assert.Equal(string.Empty, actual);
        }
    }
}
