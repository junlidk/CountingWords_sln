﻿using Moq;
using System;
using System.Collections.Generic;
using UniqueWordCounterTypes;
using Xunit;

namespace UniqueWordCounter.Test
{
    public class TextFileWordCounterTests
    {
        [Theory]
        [MemberData("InputParameters")]
        public void Constructor_Throws_ArgumentNull_Exception_When_Input_Parameter_Is_Null(string fileName, TextFileValidator fileValidator)
        {
            Assert.ThrowsAny<Exception>(()=>new TextFileWordCounter(fileName,fileValidator));
        }

        [Fact]
        public void Count_Returns_Correct_Result()
        {
            //Arrange
            string fileName = @"..\..\TestFiles\Example.txt";
            var validationResultMock=new Mock<IValidationResult>();
            validationResultMock.SetupGet(v => v.IsValid).Returns(true);
            var fileValidatorMock=new Mock<IFileValidator>();
            fileValidatorMock.Setup(v=>v.Validate(It.IsAny<string>())).Returns(validationResultMock.Object);
            var sut=new TextFileWordCounter(fileName,fileValidatorMock.Object);
            //Act
            var uniqueWords = sut.Count();
            string expected = "[Go, 1];[do, 2];[that, 2];[thing, 1];[you, 1];[so, 1];[well, 1]";
            //Assert
            Assert.Equal(7,uniqueWords.Count);
            Assert.Equal(expected,string.Join(";",uniqueWords));
        }

        [Fact]
        public void Count_Returns_WordCounts_Ignore_NewLines_Comma_Dot()
        {
            //Arrange
            string fileName = @"..\..\TestFiles\MoreWords.txt";
            var validationResultMock = new Mock<IValidationResult>();
            validationResultMock.SetupGet(v => v.IsValid).Returns(true);
            var fileValidatorMock = new Mock<IFileValidator>();
            fileValidatorMock.Setup(v => v.Validate(It.IsAny<string>())).Returns(validationResultMock.Object);
            var sut = new TextFileWordCounter(fileName, fileValidatorMock.Object);
            //Act
            var uniqueWords = sut.Count();
            //Assert
            Assert.False(uniqueWords.ContainsKey(Environment.NewLine));
            Assert.False(uniqueWords.ContainsKey(","));
            Assert.False(uniqueWords.ContainsKey("."));
        }

        [Fact]
        public void Count_Returns_WordCounts_0_For_Empty_txt()
        {
            //Arrange
            string fileName = @"..\..\TestFiles\Empty.txt";
            var validationResultMock = new Mock<IValidationResult>();
            validationResultMock.SetupGet(v => v.IsValid).Returns(true);
            var fileValidatorMock = new Mock<IFileValidator>();
            fileValidatorMock.Setup(v => v.Validate(It.IsAny<string>())).Returns(validationResultMock.Object);
            var sut = new TextFileWordCounter(fileName, fileValidatorMock.Object);
            //Act
            var uniqueWords = sut.Count();
            //Assert
            Assert.Equal(0,uniqueWords.Count);
        }

        public static IEnumerable<object[]> InputParameters
        {
            get
            {
                return new[]
                {
                    new object[]{null, new TextFileValidator()},
                    new object[]{"fileName",null},
                };
            }
        }
    }
}
