﻿using System;
using UniqueWordCounter;

namespace ClientConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Please enter text file full name:");
                var textFileName = Console.ReadLine();
                var wordCounter = new TextFileWordCounter(textFileName, new TextFileValidator());
                var uniqueWords = wordCounter.Count();
                Console.WriteLine(uniqueWords.GetDisplay());
                Console.Read();
            }
            catch (Exception ex)
            {
                Console.Write($"Error: {ex.Message}");
                Console.Read();
            }
        }
    }
}
