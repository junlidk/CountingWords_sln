﻿using System.Collections.Generic;

namespace UniqueWordCounterTypes
{
    public interface IValidationResult
    {
        bool IsValid { get; set; }
        IList<string> Messages { get; }
    }
}