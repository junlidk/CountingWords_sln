﻿namespace UniqueWordCounterTypes
{
    public interface IFileValidator
    {
        IValidationResult Validate(string fileName);
    }
}