﻿using System;
using System.Collections.Generic;
using UniqueWordCounterTypes;

namespace UniqueWordCounter
{
    public class ValidateResult : IValidationResult
    {
        public bool IsValid { get; set; }

        public IList<string> Messages { get; } = new List<string>();
    }
}
