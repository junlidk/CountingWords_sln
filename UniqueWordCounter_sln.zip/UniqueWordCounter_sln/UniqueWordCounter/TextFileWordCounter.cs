﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UniqueWordCounterTypes;

namespace UniqueWordCounter
{
    public class TextFileWordCounter : IWordCounter
    {
        private readonly string _fileName;
        private static readonly char[] Seperators = { ' ',',','.' };

        public TextFileWordCounter(string fileName, IFileValidator fileValidator)
        {
            if (string.IsNullOrEmpty(fileName)) { throw new ArgumentNullException(nameof(fileName)); }
            if (fileValidator == null) { throw new ArgumentNullException(nameof(fileValidator)); }

            var validationResult = fileValidator.Validate(fileName);
            if (!validationResult.IsValid)
            {
                throw new ArgumentException(string.Join(";", validationResult.Messages), nameof(fileName));
            }

            _fileName = fileName;
        }

        public IDictionary<string, int> Count()
        {
            var uniqueWords = new Dictionary<string, int>();

            using (var fileStream = File.Open(_fileName, FileMode.Open, FileAccess.Read))
            using (var streamReader = new StreamReader(fileStream))
            {
                string line;
                while ((line = streamReader.ReadLine()) != null)
                {
                    var words = line.Split(Seperators,StringSplitOptions.RemoveEmptyEntries);
                    foreach (var word in words)
                    {
                        if (uniqueWords.ContainsKey(word))
                        {
                            uniqueWords[word]++;
                        }
                        else
                        {
                            uniqueWords.Add(word, 1);
                        }
                    }
                }
            }

            return uniqueWords;

        }
    }
}
