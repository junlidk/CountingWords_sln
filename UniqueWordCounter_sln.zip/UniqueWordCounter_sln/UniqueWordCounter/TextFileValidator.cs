﻿using System.IO;
using UniqueWordCounterTypes;

namespace UniqueWordCounter
{
    public class TextFileValidator : IFileValidator
    {
        public IValidationResult Validate(string fileName)
        {
            string validationMessage;
            var validationResult = new ValidateResult();

            if (!File.Exists(fileName))
            {
                validationMessage = $"File '{fileName}' does not exist.";
                validationResult.IsValid = false;
                validationResult.Messages.Add(validationMessage);
            }
            else
            {
                if (!fileName.EndsWith(".txt"))
                {
                    validationMessage = $"Text file is expected, but file '{fileName}' is not a text file.";
                    validationResult.IsValid = false;
                    validationResult.Messages.Add(validationMessage);
                }
                else
                {
                    validationResult.IsValid = true;
                }
            }

            return validationResult;

        }
    }
}
