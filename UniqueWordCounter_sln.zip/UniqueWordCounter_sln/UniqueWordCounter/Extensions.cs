﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniqueWordCounterTypes;

namespace UniqueWordCounter
{
    public static class Extensions
    {
        public static string GetDisplay(this IDictionary<string, int> wordCounts)
        {
            if (wordCounts == null) { throw new ArgumentNullException(nameof(wordCounts)); }
            
            StringBuilder sb = new StringBuilder();

            foreach (var wordCount in wordCounts)
            {
                sb.AppendLine($"{wordCount.Value} : {wordCount.Key}");
            }

            return sb.ToString();
        }


    }
}
